package com.example.epoka;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.Buffer;

public class ConnectActivity extends Activity {
    private String urlServiceWeb;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.connect_screen);
    }
    public void connect(View view) {
        EditText no = (EditText) findViewById(R.id.etNo);
        EditText motDePasse = (EditText) findViewById(R.id.etMotDePasse);

        urlServiceWeb = "http://"+getString(R.string.serveur)+"";

        TacheAsynchrone tacheAsynchrone = new TacheAsynchrone();
        tacheAsynchrone.execute();
    }

    private String getServerDataTexteBrut(String urlString) {
        String ch = " ";

        try {
            URL url = new URL(urlString);
            HttpURLConnection connexion = (HttpURLConnection)url.openConnection();
            connexion.connect();
            InputStream is = connexion.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String ligne;
            while ((ligne=br.readLine()) != null) {
                ch = ch+ligne;
            }

        } catch (Exception e) {
            Log.e("log_tag", "Erreur pendant la récupération des données : " + e.toString());
        }
        return (ch);
    }

    private class TacheAsynchrone extends AsyncTask<Void, Integer, String> {

        @Override
        protected String doInBackground(Void... arg0) {
            return  (getServerDataTexteBrut(urlServiceWeb));
        }

        @Override
        protected void onPostExecute(String result) {
            while (result.length()<8) result += " ";
            if (result.substring(0,8).equals("Bonjour")) {
                Intent intent = new Intent(ConnectActivity.this, MenuActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK + Intent.FLAG_ACTIVITY_NEW_TASK);
                EditText no = (EditText) findViewById(R.id.etNo);
                intent.putExtra("no",no.getText().toString());
                intent.putExtra("nomPrenom",result);
                startActivity(intent);
            } else {

            }
        }


    }
}


