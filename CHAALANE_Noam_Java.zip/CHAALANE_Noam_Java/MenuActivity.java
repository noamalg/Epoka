package com.example.epoka;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MenuActivity extends Activity {
    private String no = "0";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_screen);

        int monNo=ConnectActivity.noUser;

        Intent intent= getIntent();
        no = intent.getStringExtra("no");
        String nomPrenom=intent.getStringExtra("nomPrenom");
        TextView tvNomPrenom = (TextView) findViewById(R.id.tvNomPrenom);
        tvNomPrenom.setText(nomPrenom);
    }
    public void ajouterMission(View view) {
        Intent intent = new Intent(getApplicationContext(), GetActivity.class);
    }
}
