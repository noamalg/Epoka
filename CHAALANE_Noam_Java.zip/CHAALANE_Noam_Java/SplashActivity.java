package com.example.epoka;

public class SplashActivity {
}
