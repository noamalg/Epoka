package com.example.epoka;

public class GetActivity {
}
